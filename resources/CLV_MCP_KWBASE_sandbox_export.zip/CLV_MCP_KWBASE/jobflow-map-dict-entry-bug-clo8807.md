tags: jobflow, dictionary, map, bug, workaround, crash
description: CLO-8807: writing to a map-typed dict entry populated from upstream causes random crashes — always copy to a local entry first
created: 2026-04-15
updated: 2026-04-15
---

## CLO-8807: Map Dictionary Entry Write Crash

**Source:** RunJob.jbf in DWHExample (code comment confirms workaround).

### Problem
Writing to a `map`-typed dictionary entry that was populated from an upstream component (e.g. passed in via inputMapping from a parent jobflow) causes **random, intermittent crashes**. The crash is non-deterministic — the same code works sometimes and fails other times.

Affected dict entry types: `map[string, string]`, `map[string, long]`, and likely other map variants.

### Root cause
When a map dict entry is populated by an upstream EXECUTE_GRAPH/EXECUTE_JOBFLOW outputMapping and the same entry is then written to directly (e.g. `dictionary.myMap['key'] = value`), internal state corruption occurs.

### Fix — always copy to a local entry before writing
Declare two dict entries: one for the incoming value, one as a local working copy:

```xml
<Dictionary>
  <Entry name="jobStatistics" type="map" contentType="long" input="true" output="false"/>
  <!-- local copy — downstream writes go here -->
  <Entry name="__jobStatistics" type="map" contentType="long" input="false" output="true" dictval.value="0"/>
</Dictionary>
```

In the component that initializes the token (DATA_GENERATOR or REFORMAT), copy immediately:
```ctl
// WRONG — crashes randomly when jobStatistics was populated from upstream:
dictionary.jobStatistics['jobRunId'] = str2long(getParamValue('RUN_ID'));

// CORRECT — copy first, then write to the copy:
dictionary.__jobStatistics = dictionary.jobStatistics;
dictionary.__jobStatistics['jobRunId'] = str2long(getParamValue('RUN_ID'));
```

All downstream components use `dictionary.__jobStatistics` for both reads and writes.
The `__` prefix naming convention signals "local working copy" (used consistently in DWHExample).

### When this matters
Any jobflow that:
- receives a map dict entry as input from a parent (input=true)
- writes new keys into that same map entry within the child jobflow

Single-level jobflows that initialize the map themselves (DATA_GENERATOR with no upstream dict) are not affected.
