tags: scd, dwh, dimension, data-intersection, hash, pattern, db
description: SCD Type 2 dimension loading pattern: DATA_INTERSECTION + checksum hashing + temporary table. Source: ProductDimWriter.sgrf in DWHExample.
created: 2026-04-15
updated: 2026-04-15
---

## SCD Type 2 Dimension Loading — CloverDX Pattern

Source: ProductDimWriter.sgrf in DWHExample sandbox (graph/subgraph/dwh-loader/writers/).
Also implemented identically in StoreDimWriter.sgrf and DiscountCampaignDimWriter.sgrf.

---

### Dimension table technical columns

Every SCD2 dimension table requires these alongside business fields:

| Column | Type | Purpose |
|---|---|---|
| `_id` | long/identity | Surrogate key (DB-generated) |
| `_natural_key_id` | long | Surrogate key of the first row for this business key |
| `_natural_key_hash` | string | MD5 of business key field(s) — join key for DATA_INTERSECTION |
| `_checksum` | string | MD5 of all tracked (non-technical) fields — change detection |
| `_valid_from` | date | Row effective date (from source increment column) |
| `_valid_to` | date | Row expiry date (MAX_DATE when active) |
| `_is_active` | integer | 1=current, 0=historical |

---

### Multi-phase graph structure

**Phase 0 — Add technical fields to source records**

REFORMAT computes and adds technical fields. Use `init()` to read params once and cache:

```ctl
import '${TRANS_DIR}/common/Hash.ctl';
string validFromColumn;
date validTo;
integer isActive;
string naturalKeyColumns;

function boolean init() {
    validFromColumn = getParamValue('SOURCE_DB_INCREMENT_COLUMN');
    setExcludedFields(getParamValue('TARGET_EXCLUDE_FIELDS')); // exclude from checksum
    validTo = str2date(getParamValue('MAX_DATE'), getParamValue('DATE_FORMAT'));
    isActive = 1;
    naturalKeyColumns = getParamValue('TARGET_DB_TABLE_NATURAL_KEY_COLUMN');
    return true;
}

function integer transform() {
    $out.0.* = $in.0.*;
    $out.0._valid_from = getDateValue($in.0, validFromColumn);
    $out.0._valid_to = validTo;
    $out.0._is_active = isActive;
    $out.0._natural_key_hash = getNaturalKeyHash(naturalKeyColumns);
    $out.0._checksum = getRecordHash();
    return ALL;
}
```

SIMPLE_COPY after technical fields splits the enriched stream:
- Copy 1 → EXT_SORT by `_natural_key_hash` → DATA_INTERSECTION port 1 (set B = source)
- Copy 2 → write only `_natural_key_hash` to temp table (DB_OUTPUT_TABLE)

**Phase 1 — Create temporary table**

```sql
create table "${TEMPORARY_TABLE_NAME}" ("_natural_key_hash" TEXT);
```
Name pattern: `_${RUN_ID}` (unique per run).

**Phase 2 — Fill temp table with source natural key hashes**

DB_OUTPUT_TABLE writes only `_natural_key_hash` from source. This avoids loading all
source data into DB — only keys needed for comparison.

**Phase 3 — Read current dimension rows matching source, sort, compare**

DB_INPUT_TABLE query fetches only current rows whose keys appear in source batch:
```sql
select d._id, d._natural_key_id, d._natural_key_hash, d._checksum
from product_dim d
join "${TEMPORARY_TABLE_NAME}" t on d._natural_key_hash = t._natural_key_hash
where d._is_active = 1
```
EXT_SORT sorts these by `_natural_key_hash`.

DATA_INTERSECTION joinKey: `$_natural_key_hash=$_natural_key_hash`
- Port 0 (set A): current dimension rows from DB — sorted by `_natural_key_hash`
- Port 1 (set B): enriched source records — sorted by `_natural_key_hash`

DATA_INTERSECTION output ports:
- **Port 0 (only in A)**: in DB but not in today's source → sent to TRASH (soft-delete not handled in this pattern)
- **Port 1 (in A & B)**: matched — transform() compares checksums:
  - Equal checksums → `return SKIP` (no change)
  - Different checksums → copy source row, carry existing `_id` and `_natural_key_id` → changed record
- **Port 2 (only in B)**: new business keys → insert with MIN_DATE as `_valid_from`

DATA_INTERSECTION transform:
```ctl
function integer transform() {
    if ($in.1._checksum == $in.0._checksum) {
        return SKIP;  // unchanged
    }
    $out.0.* = $in.1.*;                                         // new data from source
    setLongValue($out.0, identityFieldName, $in.0.id);          // carry old _id for close-out
    $out.0._natural_key_id = $in.0._natural_key_id;             // preserve history lineage
    return ALL;  // changed
}
```

New records (port 2) get `_valid_from` = MIN_DATE via a downstream REFORMAT before merging
with changed records via SIMPLE_GATHER → single INSERT stream.

**Phase 4 — Apply changes (parallel UPDATE + INSERT)**

UPDATE — close-out old row for changed records:
```sql
update "${TARGET_DB_TABLE}" set "_valid_to"=$_valid_from, "_is_active"=0 where "_id"=$_id
```
The new row's `_valid_from` becomes the close-out date for the old row — no timeline gap.

INSERT — new rows (new business keys) and changed rows (new current version):
```sql
insert into "${TARGET_DB_TABLE}" (..., _valid_from, _valid_to, _is_active, ...) values (...)
```
Both new and changed records go to the same INSERT component.

**Phase 5 — Backfill `_natural_key_id` for newly inserted rows**

```sql
update "${TARGET_DB_TABLE}" set _natural_key_id = _id where _natural_key_id is null
```
Makes first-ever rows for a business key point to their own `_id`.

**Phase 6 — Drop temporary table**

```sql
drop table "${TEMPORARY_TABLE_NAME}";
```

---

### Hash.ctl — reusable hashing library

Located at `${TRANS_DIR}/common/Hash.ctl` in DWHExample. Import with:
```ctl
import '${TRANS_DIR}/common/Hash.ctl';
```

- `getRecordHash()` — MD5 of all non-technical fields on `$in.0`. Exclude fields first
  via `setExcludedFields(semicolonSeparatedNames)`. Used as `_checksum`.
- `getNaturalKeyHash(keyColumns)` — MD5 of specified field names (semicolon-separated)
  on `$in.0`. Used as `_natural_key_hash`.
- Both use: `byte2hex(md5(str2byte(join('', data), 'utf-8')))`.
- Date fields serialized as `yyyy-MM-dd HH:mm:ss.SSS` for consistent hashing.

---

### Key graph parameters

| Parameter | Purpose |
|---|---|
| `TARGET_DB_TABLE` | Dimension table name |
| `TARGET_DB_TABLE_NATURAL_KEY_COLUMN` | Business key field(s), semicolon-separated |
| `TARGET_DB_TABLE_IDENTITY_COLUMN` | Surrogate key column name (e.g. `_id`) |
| `SOURCE_DB_INCREMENT_COLUMN` | Source field used as `_valid_from` |
| `TARGET_EXCLUDE_FIELDS` | Fields excluded from `_checksum` (must include `_valid_from` itself) |
| `MAX_DATE` | Sentinel for active rows (e.g. `9999-12-31`) |
| `MIN_DATE` | Default `_valid_from` for brand-new records |
| `DATE_FORMAT` | Java format string for MAX_DATE/MIN_DATE parsing |
| `TEMPORARY_TABLE_NAME` | Defaults to `_${RUN_ID}` |

---

### Critical design notes

1. **Join key is `_natural_key_hash`, not the raw business key field.** Both DATA_INTERSECTION
   inputs must be sorted by `_natural_key_hash` via EXT_SORT.

2. **Temporary table is the efficiency lever.** Without it, DB_INPUT_TABLE would load the entire
   dimension into CloverDX. The temp table restricts the DB read to only rows matching today's
   source batch.

3. **Phase ordering is load-bearing.** Temp table must be created (Phase 1) and filled (Phase 2)
   before the DB join read (Phase 3). INSERT/UPDATE (Phase 4) must complete before backfilling
   `_natural_key_id` (Phase 5). CloverDX phases run sequentially — do not merge phases.

4. **`_valid_from` must be excluded from `_checksum`** via `TARGET_EXCLUDE_FIELDS`. Otherwise
   every daily reload is detected as a change because the load date differs.

5. **Deleted records (DATA_INTERSECTION port 0) are not handled** in this pattern — rows in DB
   but absent from source are ignored (sent to TRASH). To handle soft deletes, add processing
   on port 0: REFORMAT to set `_valid_to` and `_is_active=0`, then DB_OUTPUT_TABLE UPDATE.

6. **Both changed and new records go to the same INSERT.** Changed records already carry the
   new field values; only their `_valid_from` source differs. New records get MIN_DATE from a
   REFORMAT before merging with changed records.

7. **Checksum comparison inside DATA_INTERSECTION transform, not downstream.** Using `return SKIP`
   inside the DATA_INTERSECTION transform eliminates unchanged matched records before they reach
   any writer — cleaner than filtering downstream.
