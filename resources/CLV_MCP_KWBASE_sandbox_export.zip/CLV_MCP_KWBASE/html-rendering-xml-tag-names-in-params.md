tags: rendering, json_writer, xml, html, clover_element, mapping
description: HTML rendering converts short XML element names in tool params — name→n, system→s. Use clover:element clover:name= workaround
created: 2026-04-13
updated: 2026-04-13
---

# HTML Rendering Converts Short XML Tag Names in Tool Parameters

## Problem — confirmed via byte-level testing

The Claude interface HTML-renders tool call parameters before sending them to tools. Specifically, **certain short XML element names get converted** when used as tag names in tool parameter values.

Confirmed conversions (INPUT side — what I type vs what reaches the tool):

| Typed in parameter | Stored on disk |
|---|---|
| `<n>foo</n>` | `<n>foo</n>` ✓ (trivial — same) |
| `<name>foo</name>` | `<n>foo</n>` ✗ (converted!) |
| `<s>foo</s>` | `<s>foo</s>` ✓ (trivial — same) |
| `<system>foo</system>` | `<s>foo</s>` ✗ (converted!) |
| `<columnName>foo</columnName>` | `<columnName>foo</columnName>` ✓ (longer names survive) |
| `<dataRetentionDays>foo</dataRetentionDays>` | `<dataRetentionDays>foo</dataRetentionDays>` ✓ |

`<name>` → `<n>` and `<system>` → `<s>` because the HTML renderer treats these as recognized/short HTML element names and truncates or strips the suffix.

The OUTPUT side has the same issue: `read_file` displaying `<n>` or `<s>` may actually mean the file contains `<name>` or `<system>` — but byte-level inspection (grep_files in JSON output) can reveal the truth.

## Solution — use clover:element with clover:name attribute

Instead of using XML element names for JSON keys that would be affected by HTML rendering, use the CloverDX `clover:element` syntax where the key name is an XML **attribute value** (not an element name). Attribute values are NOT HTML-rendered.

```xml
<!-- BROKEN — <name> gets stored as <n> -->
<name>$0.name</name>

<!-- CORRECT — clover:name="name" attribute value is not rendered -->
<clover:element clover:name="name">$0.name</clover:element>

<!-- BROKEN — <system> gets stored as <s> -->
<system>$1.system</system>

<!-- CORRECT -->
<clover:element clover:name="system">$1.system</clover:element>
```

This is already the required syntax for JSON keys that contain special characters (like `@type`), so it's valid CloverDX JSON_WRITER mapping syntax.

## Affected tag names (non-exhaustive)

Any XML element name that is also a recognized or abbreviated HTML tag name is at risk:
- `name` → `n` (HTML `<name>` treated as unknown `<n>`)
- `system` → `s` (HTML `<system>` treated as unknown `<s>`)
- Check other 4–8 character tag names that resemble HTML elements

Safe tag names (longer, not HTML-like): `columnName`, `technicalName`, `effectiveDates`, `dataRetentionDays`, `visibility`, `restrictedToLookup`, `batchKey`, `lookupKey`, `enabled`, `editable`.

## Diagnosis workflow

If a JSON_WRITER mapping produces wrong key names at runtime:
1. Enable `debugPrint=true` on the REST_CONNECTOR downstream
2. Check the request body in the execution log — the server error will name the unrecognized field
3. Use `grep_files` to check the raw bytes in the mapping (grep output is JSON-encoded — reliable)
4. Replace any short XML element names with `<clover:element clover:name="correct_name">` syntax
