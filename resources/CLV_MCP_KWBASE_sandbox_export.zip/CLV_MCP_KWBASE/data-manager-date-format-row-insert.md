tags: date, datetime, format, rest-api, row-insert, data-manager
description: Data Manager API date field format for row insert — must include milliseconds and timezone offset
created: 2026-04-13
updated: 2026-04-13
---

# Data Manager API — Date Field Format for Row Insert

## Required format

Date fields in the Data Manager REST API v1 row insert payload (`POST /transactional-data-sets/{code}/rows`) must use ISO 8601 datetime with **milliseconds AND explicit timezone offset**:

```
"YYYY-MM-DDTHH:mm:ss.SSS+HH:mm"
```

### Examples from API documentation

```json
"2025-08-28T16:26:40.248+02:00"   ✅ works
"2022-03-27T02:00:00.000+01:00"   ✅ works
"9999-12-31T23:59:59.000Z"        ✅ works (Z accepted with milliseconds)
"0001-01-01T00:00:00.000+00:00"   ✅ works
```

### Formats that FAIL

```
"1978-03-15"                       ❌ no time — fails at index 10
"1978-03-15T00:00:00"              ❌ no timezone — fails at index 19
"1978-03-15T00:00:00Z"             ❌ Z without milliseconds — fails at index 19
"1978-03-15T00:00:00+00:00"        ❌ offset without milliseconds — fails at index 19
```

**Milliseconds are mandatory.** The error "could not be parsed at index N" where N = length of the string means the parser expected more characters.

## CTL pattern for midnight dates from date strings

```ctl
r["dateOfBirth"] = dob + "T00:00:00.000+00:00";
```

Where `dob` is a string like `"1978-03-15"`.

## Tags
date, datetime, format, rest-api, row-insert, data-manager
