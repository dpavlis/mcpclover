tags: jobflow, combine, deadlock, parallel, simple_gather, antipattern
description: COMBINE deadlocks when a parallel branch fails and its token doesn't reach COMBINE — use incompleteTuples=true and SIMPLE_GATHER for errors
created: 2026-04-15
updated: 2026-04-15
---

## COMBINE with Parallel Branches — incompleteTuples Required

**Source:** RunLoad.jbf in DWHExample (`incompleteTuples="true"` on COMBINE).

### Problem
When COMBINE is used to merge results from N parallel EXECUTE_GRAPH/EXECUTE_JOBFLOW branches, and one branch fails (its token routes to the error port instead of COMBINE), **COMBINE deadlocks waiting for the missing tuple** — it expects one token per input port per tuple and blocks forever.

This is silent: no error, no timeout, the jobflow just hangs.

### Pattern — COMBINE for parallel result merging
Typical parallel dimension load:
```
SIMPLE_COPY → EJF(dim_A) port 0 → COMBINE port 0 → next step
            → EJF(dim_B) port 0 → COMBINE port 1
            → EJF(dim_C) port 0 → COMBINE port 2
```
If EJF(dim_B) fails, its token exits via port 1 (error). COMBINE never receives input on port 1 → deadlock.

### Fix — always set incompleteTuples="true" when branches can fail
```xml
<Node type="COMBINE" incompleteTuples="true" id="COMBINE"/>
```

With `incompleteTuples="true"`, COMBINE proceeds with whatever tokens arrive and does not block on missing inputs. The failed branch's token is handled separately by the error path.

### Companion pattern — SIMPLE_GATHER for unified error handling
Route all branch error ports to a single SIMPLE_GATHER → FAIL:
```
EJF(dim_A) port 1 → SIMPLE_GATHER port 0 → FAIL
EJF(dim_B) port 1 → SIMPLE_GATHER port 1
EJF(dim_C) port 1 → SIMPLE_GATHER port 2
```
The first error token to arrive at FAIL aborts the jobflow with the error message. SIMPLE_GATHER is non-blocking — it routes each token independently.

### Rule
**Any COMBINE in a parallel branch pattern must have `incompleteTuples="true"` if any upstream EXECUTE_GRAPH/EXECUTE_JOBFLOW has its error port connected.** If the error port is not connected at all (stopOnFail=false), the token may still disappear from the COMBINE input — same deadlock risk.
