tags: subgraph, validation, rest_connector, topology, metadata
description: Common validation failures in subgraphs and their fixes — topology rules, metadata, endpoint patterns
created: 2026-04-13
updated: 2026-04-13
---

# Subgraph Validation Patterns — Common Failures and Fixes

## 1. SUBGRAPH_OUTPUT → FAIL edge is forbidden

**Error:** `Invalid subgraph layout. Edge from [SubgraphOutput:X] to [Fail:Y] is not allowed.`

**Cause:** You cannot connect an outgoing edge of SUBGRAPH_OUTPUT directly into a FAIL node.

**Fix:** Fan through SIMPLE_GATHER:
```
error_source → SIMPLE_GATHER:port0
SIMPLE_GATHER:port0(out) → SUBGRAPH_OUTPUT:errorPort
SIMPLE_GATHER:port1(out) → FAIL:0
```
The SIMPLE_GATHER acts as a splitter — port 0 out goes to SUBGRAPH_OUTPUT, port 1 out goes to FAIL.

## 2. Missing SubgraphInput component causes "Missing SubgraphInput" error

**Error:** `Missing SubgraphInput component.`

**Cause:** Every subgraph requires exactly one SUBGRAPH_INPUT node, even if the subgraph has no input ports (reader pattern). The validator requires the node to be present.

**Fix:** Add an orphaned SUBGRAPH_INPUT node with no edges:
```xml
<Node guiName="SubgraphInput" guiX="50" guiY="22" id="SUBGRAPH_INPUT0" type="SUBGRAPH_INPUT">
    <Port guiY="142" name="0"/>
</Node>
```

## 3. REST_CONNECTOR endpoint using ${GRAPH_PARAM} not found in OpenAPI spec

**Error:** `This endpoint is not available in the OpenAPI specification.` (WARNING → causes FAIL)

**Cause:** Endpoint like `/reference-data-sets/${DATA_SET_CODE}/rows` uses graph parameter substitution directly in the endpoint string. The OpenAPI validator cannot match this against the spec's template paths.

**Fix:** Use `{paramName}` template syntax in the endpoint and supply the value via `requestParameters`:
```xml
endpoint="/reference-data-sets/{dataSetCode}/rows"
requestParameters="dataSetCode=${DATA_SET_CODE}&#10;"
```
In inputMapping, pass it as a string:
```ctl
$out.2.dataSetCode = $in.0.dataSetCode;  // if already string
$out.2.rowId = "" + $in.0.rowId;          // long → string via concatenation
```
Note: `(string) $in.0.rowId` is NOT valid CTL2 cast syntax. Use `"" + value` or `num2str(value)`.

## 4. Metadata on SUBGRAPH_INPUT/MAP_INPUT edges missing

**Error:** `Metadata on input port 0 are not defined.` / `Metadata on output port 0 are not defined.`

**Fix:** Add `metadata="MetaId"` attribute to the edge connecting SUBGRAPH_INPUT to the first component. Every edge in a subgraph must have explicit metadata.

## 5. Metadata inside Phase instead of Global

**Error:** `Cannot find metadata ID 'MetaXxx'.` when used from a different component.

**Cause:** `<Metadata>` elements placed inside `<Phase>` are not globally scoped and may not be visible to all components.

**Fix:** All `<Metadata>` must be declared inside `<Global>`, not inside a `<Phase>`.

## 6. Parameterized MAP_INPUT (INPUT_MAPPING parameter) needs a non-empty default

**Error:** `Transformation is not defined.`

**Cause:** A REFORMAT node whose transform is `${INPUT_MAPPING}` where the graph parameter has no default value — the validator has nothing to compile.

**Fix:** Always provide a sensible default CTL value on the GraphParameter:
```xml
<GraphParameter name="INPUT_MAPPING" ...>
  <attr name="value">//#CTL2
function integer transform() {
    $out.0.dataSetCode = $in.0.dataSetCode;
    return ALL;
}</attr>
</GraphParameter>
```

## 7. Subgraph input metadata incompatible with caller's metadata

**Error:** `Incompatible input metadata. Input metadata on port #0 does not match subgraph metadata.`

**Cause:** The caller passes records with field set A, but the subgraph declares input metadata with field set B — the validator requires caller metadata to be a superset of the subgraph's declared input fields.

**Fix:** Insert a REFORMAT between caller and subgraph to map the caller's fields to the subgraph's expected fields. Keep the subgraph's internal metadata clean for its own CTL logic. Do not widen the subgraph metadata to include caller-specific fields.

Example: `DeleteAllDataSets` passes `{name, code, type, enabled}` but `DeleteDataSet` expects `{dataSetCode}`. Solution: add a REFORMAT node `MAP_CODE` that does `$out.0.dataSetCode = $in.0.code`.

## 8. requestParameters double-escaped when set via graph_edit_properties

**Cause:** Passing `&#13;&#10;` as the separator value causes double-escaping (`&amp;#13;`).

**Fix:** Use a literal newline in the value string. The tool will encode it correctly as `&#10;` in the XML attribute. One parameter per line:
```
dataSetCode=${DATA_SET_CODE}
rowId=
columnName=
```

## 9. DATA_GENERATOR with `import metadata "${METADATA_URL}"` fails when METADATA_URL has no default

**Error:** `Cannot parse metadata. Error when reading/parsing record metadata definition file ''`

**Cause:** The CTL compiler resolves `${METADATA_URL}` at validation time. If the parameter has no default, the path is empty and the import fails.

**Fix:** Provide a default value pointing to a sample `.fmt` file:
```xml
<GraphParameter name="METADATA_URL" value="${META_DIR}/sample.fmt" .../>
```
Create `meta/sample.fmt` with a representative minimal record.

## 10. Inserting a REFORMAT before a subgraph call requires updating __PARAM overrides

**Cause:** When a subgraph uses a `<ComponentReference>` parameter (e.g. `INPUT_MAPPING` driving a REFORMAT's transform), the caller overrides it via `attr:__INPUT_MAPPING`. If you insert an intermediate REFORMAT that renames fields (e.g. `code → dataSetCode`), the `__INPUT_MAPPING` override in the caller still references the **old** field names from before the intermediate step.

**Example:** `DeleteAllDataSets` had `__INPUT_MAPPING` doing `$in.0.code → $out.0.dataSetCode`. After inserting `MAP_CODE_TDS` (which already maps `code → dataSetCode`), the input to `DeleteDataSet` now has `dataSetCode`, so `__INPUT_MAPPING` must become `$in.0.dataSetCode → $out.0.dataSetCode`.

**Rule:** Any time you insert a field-renaming REFORMAT between a caller and a subgraph, audit all `__PARAM` attribute overrides on the subgraph node and update any field references to match the new upstream metadata.

## 11. REST_CONNECTOR "Cannot write to output port '1'" is often a topology cascade

**Error:** `Default output and error mapping initialization failed. CTL validation failed. Cannot write to output port '1'`

**Cause:** Usually appears alongside structural topology errors (e.g. SUBGRAPH_OUTPUT→FAIL forbidden edge). The validator detects that port 1 has no connected edge, so writing `$out.1` in CTL is invalid.

**Diagnosis:** Fix topology errors first (add SIMPLE_GATHER, remove forbidden edges). This error typically disappears once port 1 has a properly connected edge. Do not rewrite the CTL until the topology is clean and the error persists in isolation.
