tags: patch_file, anchor, xml, angle-brackets, fixed
description: patch_file angle-bracket handling — confirmed fixed; anchor and new_content with < > now work correctly
created: 2026-04-12
updated: 2026-04-12
---

# patch_file and Angle Brackets — Fixed

## Status: FIXED (MCP update applied)

`patch_file` now handles `<` and `>` correctly in both **anchor** strings and **new_content** values. Anchor matching is performed as a literal substring match against raw UTF-8 file content with no HTML/XML entity decoding applied.

## Verified behaviour (post-fix)

| Test | Result |
|---|---|
| Anchor string `<n>$0.name</n>` finds the correct line | ✅ `anchor_line: 3` |
| Anchor string `<s>$1.system</s>` finds the correct line | ✅ `anchor_line: 5` |
| `new_content` containing `<dataRetentionDays>...</dataRetentionDays>` written and read back verbatim | ✅ |
| dry_run preview shows correct matched and replaced lines | ✅ |

## Pre-fix behaviour (for reference)

Before the fix, any anchor containing `<` or `>` returned `anchor_not_found`, even when the target text was confirmed present in the file. The workaround was to use a nearby context line without angle brackets as the anchor, combined with `from_offset`/`to_offset` to reach the target line.

## Display rendering note

The **chat interface** still HTML-renders certain short XML element names (e.g. `<n>`, `<s>`) in tool output, making them appear stripped in the display. This is a visual artifact only — the bytes on disk are correct. Longer, non-HTML tag names like `<dataRetentionDays>` are not affected and display correctly. See KB entry `xml-tag-rendering-in-tool-output` for details.

## Tags
patch_file, anchor, angle-brackets, xml, fixed
