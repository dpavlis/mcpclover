tags: data-reader, csv, fio-banka, charset, line-reading
description: How to read complex CSV file with header & footer structures (not 100% CSV compliant) in CloverDX — correct line-by-line pattern and charset
created: 2026-04-11
updated: 2026-04-11
---

# Reading complex CSV (with header/body/footer sections)

## File properties
- Charset: windows-1250 (ISO-8859-2 compatible; byte 0xF8 = ř)
- Line endings: `\n` only (Unix LF) — NOT `\r\n`, NOT `\r`
- ~95 lines total: ~8 header/info lines + 1 column-header + ~85 data rows + 1 Součet footer
- Field delimiter: `;` (semicolon), 15 fields per data row
- Czech number format in amount fields: space as thousands separator, comma as decimal point

## Why direct DATA_READER fails
- `dataPolicy="lenient"` silently drops ALL records when the file is hard to parse — produces 0 output with no error
- `skipRows=N` does NOT skip lines before parsing; it skips after parsing. If parsing itself fails (wrong delimiter/structure), skipRows cannot help
- Setting `charset` on the `<Record>` element causes 0 records — charset belongs on the DATA_READER Node only (as `<attr name="charset">`)
- Setting BOTH `recordDelimiter="\n"` on Record AND `delimiter="\n"` on the field simultaneously produces ambiguous results (8 records from a 95-line file)

## Correct reading pattern — two-stage

### Stage 1: LineMeta (single-field line reader)
```xml
<Metadata id="MetaLine">
  <Record name="raw_line" type="delimited">
    <Field eofAsDelimiter="true" name="line" type="string" delimiter="\n"/>
  </Record>
</Metadata>
```
Rules:
- NO `recordDelimiter` on `<Record>` — field delimiter drives boundaries
- `eofAsDelimiter="true"` — handles last line without trailing newline
- `|` in delimiter value is NOT an OR operator in CloverDX — it's a literal character

### Stage 1: DATA_READER node
```xml
<Node enabled="enabled" guiName="Read Lines" id="READER_LINES" type="DATA_READER">
  <attr name="fileURL"><![CDATA[${DATAIN_DIR}/Obchody.csv]]></attr>
  <attr name="charset"><![CDATA[windows-1250]]></attr>
</Node>
```
- All node config goes as `<attr>` CDATA children, NOT as XML attributes on the Node tag
- No `skipRows`, no `dataPolicy` — filter downstream

### Stage 2: REFORMAT filter — keep data rows only
Data rows start with a date DD.MM.YYYY. Filter:
```ctl
if (isnull(line) || length(trim(line)) == 0) return SKIP;
string clean = trim(line);
if (!contains(clean, ";")) return SKIP;
string firstField = trim(split(clean, ";")[0]);
if (!matches(firstField, "^\\d{2}\\.\\d{2}.*")) return SKIP;
$out.0.line = clean;
return ALL;
```
- Trims residual `\n` from header lines (handles any CRLF remnants)
- Date check rejects: blanks, title rows, column header row, Součet footer

### Stage 3: port-reading second DATA_READER — full 15-field parse
```xml
<Node enabled="enabled" guiName="Parse CSV Lines" id="PARSER" type="DATA_READER">
  <attr name="fileURL"><![CDATA[port:$0.line:discrete]]></attr>
  <attr name="charset"><![CDATA[windows-1250]]></attr>
  <attr name="dataPolicy"><![CDATA[strict]]></attr>
</Node>
```
MetaParsed — last field must have `eofAsDelimiter="true"`:
```xml
<Metadata id="MetaParsed">
  <Record fieldDelimiter=";" name="obchody_row" type="delimited">
    <Field name="DatumObchodu" type="string"/>
    ... (13 more string fields) ...
    <Field eofAsDelimiter="true" name="Trailing" type="string" delimiter="\n"/>
  </Record>
</Metadata>
```
Edge to PARSER input: `inPort="Port 0 (input)"` (not "Port 0 (in)")

## Field structure (data rows)
0 DatumObchodu, 1 Smer, 2 Symbol, 3 Cena, 4 Pocet, 5 Mena,
6 ObjemCZK, 7 PoplatkyCZK, 8 ObjemUSD, 9 PoplatkyUSD,
10 ObjemEUR, 11 PoplatkyEUR, 12 TextFIO, 13 Stav, 14 Trailing

Amount column by currency: CZK→ObjemCZK, USD→ObjemUSD, EUR→ObjemEUR

## Dividend/tax classification
- Dividend: TextFIO contains "Dividenda" AND NOT "z divid"
- Tax: TextFIO contains "z divid"
- Parse amount: `replace(replace(trim(raw), " ", ""), ",", ".")` then `str2decimal()`
