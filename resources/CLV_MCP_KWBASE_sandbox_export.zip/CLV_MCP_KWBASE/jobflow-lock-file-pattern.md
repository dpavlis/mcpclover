tags: jobflow, lock, mutex, create_files, delete_files, list_files, concurrency, pattern
description: Three-part jobflow lock file pattern for mutual exclusion: acquire (CREATE_FILES stopOnFail=false), release (DELETE_FILES error→TRASH), pre-check (LIST_FILES stopOnFail=false)
created: 2026-04-15
updated: 2026-04-15
---

## Jobflow Lock File Pattern — Mutual Exclusion Between Concurrent Runs

**Source:** Main.jbf, DWHExampleBulkGenerator.jbf, DWHExampleScheduledGenerator.jbf in DWHExample.

### Use case
Prevent two jobflows from running concurrently when they share a resource (files, DB tables, sequences). The lock is a file whose presence signals "in use".

---

### Part 1 — Acquire lock (at start, Phase 0)
```xml
<Node type="CREATE_FILES"
      fileURL="${SCHEDULED_FILE_LOCK}"
      stopOnFail="false"
      id="LOCK"/>
```
**`stopOnFail="false"` is mandatory.** If the lock file already exists (previous run didn't clean up, or another instance is running), CREATE_FILES will fail. Without `stopOnFail="false"`, that failure aborts the jobflow before any work is done. With it, the jobflow continues — the existing file simply gets overwritten.

---

### Part 2 — Release lock (at end, last Phase)
```xml
<Node type="DELETE_FILES" fileURL="${SCHEDULED_FILE_LOCK}" id="REMOVE_LOCK"/>
<!-- Route error port to TRASH: -->
<Node type="TRASH" id="IGNORE">
    <attr name="guiDescription"><![CDATA[if lock is missing]]></attr>
</Node>
<!-- Edge: REMOVE_LOCK port 1 (error) → IGNORE -->
```
DELETE_FILES error port MUST be routed to TRASH. If the lock file is missing (manual deletion, or Phase 0 failed before creating it), DELETE_FILES fails — without TRASH on the error port, this failure aborts the jobflow unnecessarily.

---

### Part 3 — Pre-check (fail fast if locked, before doing any work)
Used in DWHExampleScheduledGenerator.jbf to immediately abort if the main process is running:
```xml
<Node type="LIST_FILES"
      fileURL="${SCHEDULED_FILE_LOCK}"
      stopOnFail="false"
      id="CHECK_LOCK"/>
<!-- Port 0 (file found) → FAIL with descriptive message -->
<!-- Port 1 (error = file not found) → TRASH, continue -->
```
LIST_FILES with `stopOnFail="false"`:
- File exists → port 0 gets the file record → route to FAIL
- File not found → port 1 (error) fires → route to TRASH → proceed normally

**Error message in FAIL should name the locking process and the lock file path** so operators know what to do: `"Blocked by ${SCHEDULED_FILE_LOCK} — Main.jbf may be running. Delete the lock file manually if no process is active."`

---

### Phase placement
- Phase 0: acquire lock (or pre-check)
- Phase N (last): release lock

Phase separation ensures the lock is held for the entire duration of the work phases and released only after all work completes.

---

### Antipatterns to avoid
- CREATE_FILES without `stopOnFail="false"` → jobflow aborts if lock exists
- DELETE_FILES without TRASH on error port → jobflow fails if lock was manually removed
- Lock acquire and release in the same phase → release happens before work completes
- Not using a lock when multiple schedules can trigger the same jobflow → concurrent runs corrupt shared state
