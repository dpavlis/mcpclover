tags: binary, png, icons, list_files, copy_file, find_file, library, sandbox
description: Binary file visibility in list_files/find_file depends on sandbox type — normal sandboxes show binaries, installed library sandboxes hide them
created: 2026-04-13
updated: 2026-04-14
---

# Binary Files in Sandboxes — Visibility Depends on Sandbox Type

## Corrected finding

Binary files (PNG, JAR, etc.) are **NOT universally invisible** in CloverDX MCP tools. Visibility depends on the **type of sandbox**:

| Sandbox type | `list_files` / `find_file` visibility |
|---|---|
| Normal sandbox (DWHExample, DataManagerLibv4, etc.) | ✅ Binary files visible with sizes |
| Installed CloverDX library sandbox | ❌ Binary files invisible — empty results |

## Evidence

- `DataManagerLibv4` (normal sandbox, created by user): `list_files icons/` returns all 32 PNG files with sizes
- `DataManagerLib_3.1.0` (installed library): `list_files icons/` returns empty `[]` despite PNGs being physically present
- `NorthwindDBDemoLib_1.5` (installed library): same — `find_file *.png` returns `[]`
- `DataAnalyticsBundleLib_1.1.2`, `SyntheticDataGeneratorLib_2.0`, `AddressValidationLib_1.0`: same empty results

## Detecting installed library sandboxes

**Library sandboxes are not reliably detectable** via `list_files` / `find_file` / `grep_files` alone, since `library.json` and `library.prm` were not found in root of any sandbox (they may also be hidden by the same mechanism, or may not exist on this server version). 

**Heuristics** that correlate with library status (none individually conclusive):
- Sandbox code contains a version suffix pattern like `_3.1.0`, `_1.5`, `_2.0`, `_1.1.2`
- Root `list_files` shows **only folders, no files** (no workspace.prm, no .classpath, etc.)
- `.settings` folder exists but appears **empty** (or no `.settings` at all)

By contrast, normal sandboxes typically have files at root: `workspace.prm`, `.classpath`, `.project`, README, etc.

## Practical rule

**Before attempting to enumerate binary files in a sandbox:**
1. Run `list_files(".")` on the sandbox root
2. If result contains **no files** (only folders) → likely an installed library → binary files won't be enumerable
3. If result contains files (workspace.prm, .classpath, etc.) → normal sandbox → binary files are visible

## Workaround when binary files are not visible

When the sandbox is an installed library and `list_files`/`find_file` returns empty for binary files:
1. **Infer filenames from text references**: use `grep_files` to find `IconPath`/`IconUrl` attributes in `.sgrf`/`.rjob` files — these reveal the exact PNG filenames
2. **Copy directly by name**: `copy_file` works correctly for binary files regardless of sandbox type — the invisibility is a listing limitation, not a copy limitation

## Original (incorrect) note

The previous KB entry stated this was a general limitation of all sandboxes. That was wrong — it is specific to **installed library sandboxes** only.
