tags: rendering, xml, html, debugging, graph_edit_properties, display
description: HTML rendering strips certain XML element names in tool output display — actual file bytes are correct, display is misleading
created: 2026-04-12
updated: 2026-04-12
---

# XML Element Names Rendered as HTML in Tool Output

## Problem

When `read_file`, `bash_tool stdout`, or other tool outputs contain XML text whose element names match (or resemble) HTML tag names, the Claude chat interface HTML-renders them and the tag letters become invisible in the display. **The actual bytes on disk are correct — this is a display-only artifact.**

## Examples observed

| Actual bytes on disk | Displayed as |
|---|---|
| `<name>$0.name</name>` | appears as `<n>$0.name</n>` — "ame" eaten |
| `<system>$1.system</system>` | appears as `<s>$1.system</s>` — "ystem" eaten |
| `<enabled>true</enabled>` | shown correctly |
| `<columnName>x</columnName>` | shown correctly (not a recognized HTML tag name) |

The renderer treats `<name>` as an HTML element, renders it (invisibly) and shows only its text content — but the opening tag itself only shows the first letter in some cases. Short single-letter tag names like `<n>` and `<s>` happen to survive the render and show up, creating the illusion that the file contains the old shortened API tag names.

## Verified diagnosis

Python byte analysis on a file that read_file displayed as containing `<n>$0.name</n>` showed bytes `[60, 110, 97, 109, 101, 62]` = `<name>`. The file was correct; only the display was wrong.

## Consequence for graph editing

Do **not** repeat `graph_edit_properties` or `write_file` calls just because the read-back looks wrong. When in doubt, verify via bash byte inspection:

```python
with open('/path/to/file') as f:
    content = f.read()
line = content.split('\n')[LINE_INDEX]
print(list(line.encode()[:12]))   # check first 12 bytes
```

Or via CloverDX sandbox: look for a line length mismatch — `<name>$0.name</name>` is 22 chars; `<n>$0.name</n>` is only 18.

## Related pitfall

This same rendering affects the **input** side too: when you write `<name>` in a tool call `value` parameter it may also get stripped by the renderer before reaching the tool. Use `graph_edit_properties` with the `attr:` prefix for CDATA content — it handles XML-unsafe content robustly. Avoid `patch_file` for XML content inside CDATA blocks if the new_content contains angle-bracket tag names.

## Tags
rendering, display, xml, html, debugging, graph_edit_properties
