tags: ctl2, nvl, isblank, rest_connector, error-handling, empty-string
description: CTL2 nvl() returns empty string unchanged — use isBlank() instead when you need to replace both null and empty; REST_CONNECTOR errorMessage is "" not null for HTTP errors
created: 2026-04-13
updated: 2026-04-13
---

# CTL2: nvl() Does NOT Replace Empty Strings — Only Null

## Problem

`nvl(value, default)` in CTL2 returns `default` only when `value` is **null**. If `value` is an empty string `""`, `nvl()` returns `""` — it does NOT fall through to `default`.

This catches developers coming from SQL, where `COALESCE`/`NVL` typically treats empty strings as non-null but some dialects treat `''` as null.

## Example of the bug

```ctl
// REST_CONNECTOR defaultOutputMapping populates errorMessage as "" (empty string)
// for HTTP errors — not null. content holds the response body.

$out.0.errorMessage = "Failed (HTTP " + $in.0.statusCode + "): "
    + nvl($in.0.errorMessage, $in.0.content);
// If errorMessage = "" and content = "Bad Request body...",
// nvl("", "Bad Request body...") returns "" — the body is LOST.
// Result: "Failed (HTTP 400): " — empty tail.
```

## Correct patterns

**Option 1 — `isBlank()` check (preferred):**
```ctl
string detail = isBlank($in.0.errorMessage) ? $in.0.content : $in.0.errorMessage;
$out.0.errorMessage = "Failed (HTTP " + $in.0.statusCode + "): " + detail;
```

**Option 2 — prefer content, fall back to errorMessage:**
```ctl
// Use content (response body) for HTTP errors; errorMessage for connection failures
string detail = isBlank($in.0.content) ? $in.0.errorMessage : $in.0.content;
```

**Option 3 — concat both (always shows something):**
```ctl
$out.0.errorMessage = "Failed (HTTP " + $in.0.statusCode + "): "
    + $in.0.content + " " + $in.0.errorMessage;
```

## REST_CONNECTOR field behaviour in defaultOutputMapping

For HTTP error responses (4xx, 5xx):
- `$in.0.statusCode` — populated with the HTTP status code ✅
- `$in.0.content` — populated with the response body ✅
- `$in.0.errorMessage` — **empty string `""`**, not null ⚠️

For connection failures (timeout, DNS, SSL):
- `$in.0.statusCode` — 0 or absent
- `$in.0.content` — empty
- `$in.0.errorMessage` — populated with the connection error message ✅

So for a robust error handler covering both cases:
```ctl
string detail = isBlank($in.0.content) ? $in.0.errorMessage : $in.0.content;
```

## Diagnosis

When FAIL or downstream error output shows "Failed (HTTP 400): " with nothing after the colon:
1. The defaultOutputMapping is likely assigning `$in.0.errorMessage` (empty string) to an output field
2. `nvl($in.0.errorMessage, $in.0.content)` is returning the empty string
3. Fix: replace `nvl()` with `isBlank()` check as shown above
