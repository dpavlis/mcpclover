tags: subgraph, insert, data-manager, rest-api, row-insert, serialization
description: TransactionalDataSetInsertRows subgraph — design, usage pattern, serialization CTL, and why pre-serialization is required
created: 2026-04-13
updated: 2026-04-13
---

# TransactionalDataSetInsertRows Subgraph — Design and Usage

## Location
`graph/subgraph/TransactionalDataSetInsertRows.sgrf` in DataManagerLibv4

## Interface

**Input port 0:** `{dataSetCode: string, rowJson: string}` — one record per row to insert.

**Output port 0:** `{dataSetCode: string, rowsInserted: long}` — one summary record on success. `keepEdge=true`.

**Output port 1:** `{errorMessage: string}` — optional error output. `keepEdge=false`.

**Parameter:** `DATA_SET_CODE` (required) — target transactional dataset code.

## How to call it

The subgraph takes **pre-serialized** rows. Callers must add a SERIALIZE_ROW REFORMAT upstream that converts any schema to the `{dataSetCode, rowJson}` format:

```ctl
//#CTL2
function integer transform() {
    variant row = {};
    row["@type"] = "CompactTransactionalRow";
    for (integer i = 0; i < length($in.0); i++) {
        string fn = getFieldName($in.0, i);
        // Skip routing field and system fields (underscore prefix)
        if (fn == "dataSetCode" || startsWith(fn, "_")) { continue; }
        string ft = getFieldType($in.0, i);
        if (ft == "date") {
            date d = getDateValue($in.0, i);
            row[fn] = isnull(d) ? null : date2str(d, "yyyy-MM-dd'T'HH:mm:ss.000+00:00");
        } else {
            row[fn] = getValue($in.0, i);
        }
    }
    $out.0.rowJson     = writeJson(row);
    $out.0.dataSetCode = "";  // blank = use DATA_SET_CODE parameter
    return ALL;
}
```

## Typical graph pattern

```
DataSource [any schema]
    ↓
SERIALIZE_ROW (REFORMAT, CTL above)
    [MetaRowJSON: {dataSetCode: string, rowJson: string}]
    ↓
TransactionalDataSetInsertRows (SUBGRAPH, __DATA_SET_CODE="MyCode")
    ↓ port 0
[MetaInsertResult: {dataSetCode, rowsInserted}]
```

## Design decisions

**Pre-serialization is the caller's responsibility** because CloverDX subgraph metadata compatibility requires a fixed schema on the input port. A generic "any schema" input is not possible in CloverDX's typed metadata system. Moving serialization to the caller follows the same convention as all other subgraphs in the library (known, specific input schemas).

**`order="Ignore"` on DENORMALIZER** — all records have the same key value (dataSetCode is constant or empty), so no upstream sort is needed. The `order=Ignore` attribute disables the sort requirement.

**Date format** — the Data Manager API requires `"yyyy-MM-dd'T'HH:mm:ss.000+00:00"` (milliseconds + offset mandatory). See KB entry `data-manager-date-format-row-insert`.

**`@type` on each row** — required by Jackson polymorphic deserialization. See KB entry `http-to-rest-connector-migration`.

## v1 limitations

- Single batch only: all input records → one HTTP POST. For large volumes (thousands of rows), chunk upstream.
- Transactional datasets only. Reference datasets have a different lifecycle.

## Why metadata compatibility required pre-serialization

CloverDX validates that the caller's metadata is compatible (exact field set match) with the subgraph's declared input metadata. Since the subgraph declares `{dataSetCode, rowJson}` and any legitimate caller will have exactly those two fields from the SERIALIZE_ROW REFORMAT, validation passes cleanly. Attempting to pass the raw data schema (e.g., `{firstName, lastName, ...}`) to the subgraph directly would fail with "Incompatible input metadata".
