tags: jobflow, phases, sequential, barrier, parallel, pattern, dependency
description: Jobflow phases enforce sequential ordering between component groups — use instead of BARRIER when strict sequencing is needed without result inspection
created: 2026-04-15
updated: 2026-04-15
---

## Jobflow Phases for Sequential Dependency Between Parallel Groups

**Source:** RunLoad.jbf in DWHExample — comment: "Dimensions are loaded in different phases (consecutively) due SQLite limitations. If standard database was used, all the dimensions could be loaded in the same phase (concurrently)."

### Key insight
In jobflows, **phases enforce sequential ordering between groups of components** exactly as in graphs. All components in phase N complete before any component in phase N+1 starts. This applies to EXECUTE_GRAPH/EXECUTE_JOBFLOW components too — they all finish in phase N before phase N+1 begins.

Use phases in jobflows when:
- Step B depends on Step A completing entirely (e.g. fact table load requires dimension loads to finish first)
- A shared resource cannot handle concurrent access (DB with write locks, single-writer file systems)
- You need a guaranteed synchronization point between groups without BARRIER complexity

### RunLoad.jbf pattern
Three dimension loaders run in phases 0, 1, 2 (sequentially), then fact load in phase 3:
```
Phase 0: STORE_DIMENSIONS (runs to completion)
Phase 1: DISCOUNT_CAMPAIGN_DIMENSIONS (runs to completion)  
Phase 2: PRODUCT_DIMENSIONS + COMBINE + error handling
Phase 3: ORDER_FACT → SUCCESS
```

Each dimension loader is an EXECUTE_JOBFLOW. Phase separation ensures dimension data is committed before the fact loader runs (foreign key integrity). With a standard concurrent-write DB, all three dimensions could be in the same phase and run in parallel.

### Phases vs BARRIER
| Approach | When to use |
|---|---|
| Phases | All components in group A must finish before group B starts; simple sequential dependency |
| BARRIER | Components run in parallel; wait for all to finish; need to inspect success/failure results |

Phases are simpler — no BARRIER configuration, no token count management. BARRIER is needed when you want to inspect the results of the parallel group (success/failure per branch) before proceeding.

### Antipattern
Putting dimension loads and fact load in the same phase (or same sequential chain without phases) when the DB cannot handle concurrent writes → intermittent deadlocks or foreign key violations depending on execution timing.

### Note on token flow across phases
In jobflows, the token must be explicitly routed from one phase's output to the next phase's input via edges. Phases do not automatically pass tokens — you need edges connecting across phase boundaries.
