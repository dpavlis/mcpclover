tags: jobflow, execute_graph, dynamic, skipcheckconfig, validation, antipattern
description: EXECUTE_GRAPH with dynamic jobURL (parameter or inputMapping override) requires skipCheckConfig=true or checkConfig fails at validation time
created: 2026-04-15
updated: 2026-04-15
---

## Dynamic jobURL in EXECUTE_GRAPH Requires skipCheckConfig

**Source:** RunJob.jbf in DWHExample — `<Node jobURL="${WORKER_URL}" skipCheckConfig="true" type="EXECUTE_GRAPH">`.

### Problem
When `jobURL` is set dynamically at runtime (either via a parameter placeholder like `${WORKER_URL}` or via inputMapping `$out.0.jobURL = $in.0.workerUrl`), CloverDX's pre-execution checkConfig phase **cannot resolve the actual graph path** and fails validation — even though the jobflow is correct and will work at runtime.

### Fix
Add `skipCheckConfig="true"` to the Node:
```xml
<Node type="EXECUTE_GRAPH"
      jobURL="${WORKER_URL}"
      skipCheckConfig="true">
    <attr name="inputMapping"><![CDATA[//#CTL2
function integer transform() {
    $out.0.jobURL = $in.0.workerUrl;  // dynamic override
    return ALL;
}]]></attr>
</Node>
```

### When to apply
- `jobURL` contains a graph parameter that is not resolved at design time
- `jobURL` is overridden in inputMapping from a token field
- The graph referenced by `jobURL` is selected at runtime based on data (e.g. different worker graphs for different data types)

### What skipCheckConfig skips
Only the pre-execution configuration check. Graph XML parsing and runtime execution still happen normally. Errors in the actual executed graph still surface at runtime.

### Note on mapping dialogs
When `jobURL` is dynamic, the inputMapping/outputMapping dialogs in CloverDX Designer cannot auto-populate the child graph's parameters and dict entries (they don't know which graph will run). You must manually specify `$out.1.PARAM_NAME` and `$out.2.dict_entry` without the dialog's help.
