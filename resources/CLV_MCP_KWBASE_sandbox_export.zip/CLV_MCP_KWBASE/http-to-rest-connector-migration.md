tags: rest_connector, http_connector, migration, endpoint, response-mapping, at-type, headers
description: Cheatsheet for migrating graphs from HTTP_CONNECTOR to REST_CONNECTOR — URL patterns, response handling, status codes, @type requirements, field name changes
created: 2026-04-13
updated: 2026-04-13
---

# HTTP_CONNECTOR → REST_CONNECTOR Migration Cheatsheet

Applies when migrating graphs from the old HTTP_CONNECTOR + manual JSON parsing pattern to the modern REST_CONNECTOR with OpenAPI spec support.

## Component replacement

| Old | New |
|---|---|
| `type="HTTP_CONNECTOR"` | `type="REST_CONNECTOR"` |
| `url="${API_URL}/path/*{param}"` | `apiRootUrl="${API_BASE_URL}"` + `endpoint="/path/{param}"` + `requestParameters` |
| `requestMethod="POST"` | `requestMethod="POST"` (same) |
| `username` / `password` | `username` / `password` (same) |
| `headerProperties` with Content-Type | same (but often not needed — OpenAPI spec declares it) |
| No OpenAPI awareness | `openApiUrl="${OPENAPI_URL}"` |

## URL / endpoint pattern

Old HTTP_CONNECTOR used `*{param}` for path substitution inline in the URL:
```
url="${API_URL}/transactional-data-sets/*{dataSetCode}/rows/*{rowId}"
```

REST_CONNECTOR uses OpenAPI-style `{param}` templates in the endpoint attribute, with parameters declared in `requestParameters` and set in `inputMapping`:
```xml
endpoint="/transactional-data-sets/{dataSetCode}/rows/{rowId}"
requestParameters="dataSetCode=&#10;rowId=&#10;"
```
```ctl
$out.2.dataSetCode = $in.0.dataSetCode;
$out.2.rowId = "" + $in.0.rowId;   // long → string
```

**Critical:** If the graph parameter value should be the static default, put it directly in requestParameters:
```
requestParameters="dataSetCode=${DATA_SET_CODE}&#10;"
```
This makes `dataSetCode` default to the graph parameter, overridable via `inputMapping`.

## Request body (POST/PUT/PATCH)

Both components use `requestContent` for static bodies and `inputMapping` for dynamic ones. The CTL is identical:
```ctl
$out.0.requestContent = writeJson(body);
```

## Response handling

| Old | New |
|---|---|
| `standardOutputMapping` CTL copies `$in.1.*` (HTTP response record) to `$out.0.*` | `defaultOutputMapping` CTL reads `$in.0.content`, `$in.0.statusCode`, `$in.0.errorMessage` |
| `errorOutputMapping` CTL for connection failures | same `defaultOutputMapping` handles both HTTP errors and connection failures |
| Downstream JSON_READER or JSON_EXTRACT for parsing | `responseMapping` XML parses response directly into output port records |
| `$in.1.content` for response body | `$in.0.content` (string) or `$in.0.contentJson` (pre-parsed variant, unique to REST_CONNECTOR) |
| Input pass-through via `$out.0.* = $in.0.*` in standardOutputMapping | Input pass-through via `$in.2.fieldName` in defaultOutputMapping |

## Response mapping (replaces JSON_READER/JSON_EXTRACT)

For list endpoints returning `{"members": [...]}`:
```xml
<attr name="responseMapping"><![CDATA[<Mappings>
    <Mapping element="HTTP_200" responsesKey="200">
        <Mapping element="body_json">
            <Mapping element="members" outPort="0"
                xmlFields="{}name;{}code;{}enabled"
                cloverFields="name;code;enabled"/>
        </Mapping>
    </Mapping>
</Mappings>
]]></attr>
```

For simple object responses, use `defaultOutputMapping` with `$in.0.contentJson`:
```ctl
variant resp = $in.0.contentJson;
$out.0.affectedRows = cast(resp["affectedRows"], long);
```

## Error port wiring

Old HTTP_CONNECTOR had a separate error port (port 1) for connection failures. REST_CONNECTOR handles everything in `defaultOutputMapping` — check `$in.0.statusCode` and branch via `if/else`:
```ctl
function integer transform() {
    if ($in.0.statusCode == 200) {
        // success path → $out.0
    } else {
        // error path → $out.1
    }
    return ALL;
}
```

## Status code differences to watch for

| Operation | Old expected | New expected |
|---|---|---|
| GET | 200 | 200 |
| POST (create) | 200 | **201 Created** |
| PATCH (bulk update) | 200 | 200 |
| DELETE | 200 | **204 No Content** |

The old API often returned 200 everywhere. The new API uses proper HTTP semantics.

## @type in request bodies — STILL REQUIRED

Despite using type-specific endpoints (e.g. `/transactional-data-sets/` instead of `/data-sets/`), the CloverDX Data Manager API v1 still requires `"@type"` in every request body object. Jackson polymorphic deserialization is applied regardless of the URL path.

| Entity | Required @type value |
|---|---|
| Dataset creation body | `"TransactionalDataSet"` or `"ReferenceDataSet"` |
| Row insert (each row) | `"CompactTransactionalRow"` |

Error when missing: `HTTP 400 — missing type id property '@type'`

For dataset creation via JSON_WRITER mapping, use `clover:element` syntax to avoid HTML rendering stripping the `@` prefix:
```xml
<clover:element clover:name="@type">$0.type</clover:element>
```

For row insert via CTL variant:
```ctl
r["@type"] = "CompactTransactionalRow";
```

## Field name changes (Data Manager API v1 → v1 new)

| Old JSON field | New JSON field |
|---|---|
| `@type` in body | still required (see above) |
| `n` (dataset name) | `name` |
| `usesValidity` | `effectiveDates` |
| Column `n` (display name) | `columnName` |
| Column `internalName` | `technicalName` |
| Column `s` (system flag) | `system` |

Note: `name` and `system` as JSON_WRITER XML element names are affected by HTML rendering — use `clover:element clover:name="name"` and `clover:element clover:name="system"` instead. See `html-rendering-xml-tag-names-in-params` KB entry.

## Computed path prefix for type-routing

When the same subgraph handles both transactional and reference endpoints, use a dynamic graph parameter:
```xml
<GraphParameter name="_DS_PATH_PREFIX">
    <attr name="dynamicValue"><![CDATA[//#CTL2
function string getValue() {
    return getParamValue("DATA_SET_TYPE") == "ReferenceDataSet"
        ? "reference-data-sets"
        : "transactional-data-sets";
}
]]></attr>
</GraphParameter>
```
Then use in endpoint: `endpoint="/${_DS_PATH_PREFIX}/{dataSetCode}/rows"`

## Required headers for modifying requests

All POST, PUT, PATCH, DELETE requests require:
```
X-Requested-By: CloverDX
Content-Type: application/json
```

Missing `X-Requested-By` returns HTTP 400: `Request header 'X-Requested-By' is required`.
